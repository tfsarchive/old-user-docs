Note:
{......}: This line will show what will be visible when you're coding in command prompt
Example: 

echo test
{test}



                        =============================================================================
                        ===== Flight Simulator X Remake Installer SDK for manually installation =====
                        =============================================================================


Table of content: 
1. Using DISM Installer Core with customize
2. Editing registries
3. Using 7-Zip File Manager to install FSX


--------------------------------------------- Using DISM Installer Core with customize ----------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------
| Flight Simulator X Remake (FSX Remake) uses Windows 11 Deployment Image                                                           |
| Servicing and Management (Dism). That explains why older versions of Windows                                                      |
| cannot use dism due the limitation of Windows.                                                                                    |
|                                                                                                                                   |
| You still can able to install FSX Remake on older version of Windows, but it requires                                             |
| 7-Zip to install it (or extract it, for sure).                                                                                    |
|                                                                                                                                   | 
| You ONLY to know the "apply-image" command-line. If you want to see more, see dism                                                |
| command-line options:                                                                                                             |
|                                                                                                                                   | 
| https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/dism-image-management-command-line-options-s14              |
|                                                                                                                                   |
|                                                                                                                                   |
| The dism's commands we used to install FSX Remake:                                                                                |
|                                                                                                                                   |
| dism /apply-image /imagefile:<path to wim file> /index:1 /applydir:<path to install>                                              |
|                                                                                                                                   |
| Parameter                    Description                                                                                          |
| /apply-image                 Apply the data to the specific path.                                                                 |
| /imagefile                   The path and name of the .wim file that will be applied.                                             |
| /index                       Index of file.                                                                                       |
| /applydir                    The directory where FSX need to be installed. Please                                                 |
|                             note that it is not possible to create any subfolders, so                                             |
|                             if the folder cannot be accessed using Windows Explorer,                                              |
|                             dism as well.                                                                                         |
|                                                                                                                                   |
| To know how to create a batch file, see here: https://www.youtube.com/watch?v=7aOW-trZTd4                                         |
|                                                                                                                                   |
| For example, if you want to install FSX in the D:\FSX and the iso were mounted to the path E:, you'd need to create a             |
| batch file, edit and save it.                                                                                                     |
|                                                                                                                                   |
|                                                                                                                                   |
| E:                                                                                                                                |
| cd "Installer Core"                                                                                                               |
| dism /apply-image /imagefile:"..\Data\FSX_Part1.wim" /index:1 /applydir:"D:\FSX"                                                  |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part2.wim" /index:1 /applydir:"D:\FSX"                                                  |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part3.wim" /index:1 /applydir:"D:\FSX"                                                  |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part4.wim" /index:1 /applydir:"D:\FSX"                                                  |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part5.wim" /index:1 /applydir:"D:\FSX"                                                  |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part6.wim" /index:1 /applydir:"D:\FSX"                                                  |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part7.wim" /index:1 /applydir:"D:\FSX"                                                  |
| cd "../Remake Settings"                                                                                                           |
| start "Install_Program.bat"                                                                                                       |
|                                                                                                                                   |
| Save the file you just edited and run it as administrator.                                                                        |
|                                                                                                                                   |
|                                                                                                                                   |
| Same here, but if you were mounted the iso to the path R: and want to install FSX to                                              |
| F:\FSX\Data                                                                                                                       |
|                                                                                                                                   |
| R:                                                                                                                                |
| cd "Installer Core"                                                                                                               |
| dism /apply-image /imagefile:"..\Data\FSX_Part1.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part2.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part3.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part4.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part5.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part6.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| pause                                                                                                                             |
| dism /apply-image /imagefile:"..\Data\FSX_Part7.wim" /index:1 /applydir:"F:\FSX\Data"                                             |
| cd "../Remake Settings"                                                                                                           |
| start "Install_Program.bat"                                                                                                       |
|                                                                                                                                   |
| Save the file you just edited and run it as administrator.                                                                        |
|                                                                                                                                   |
| When running, dism will show the progess bar like this:                                                                           |
|                                                                                                                                   |
| { Applying image                                          }                                                                       |
| { [=========                27%                         ] }                                                                       |
|                                                                                                                                   |
|   ----------------------------------------------------------------------------------------------------------------------------    |
|                                                                                                                                   |
| If dism runs into the problem because your code lines is having problem like this:                                                |
|                                                                                                                                   |
| dism /ap-iamge /index                                                                                                             |
|                                                                                                                                   |
| { Error: 87 }                                                                                                                     |
|                                                                                                                                   |
| then you know what would you do then :)                                                                                           |
|                                                                                                                                   |
-------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------- Editing registries --------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------
| Due the limitation of my code, the Installer cannot edit the registries.                                                          |
| This only can import it, eventhough import code-lines are still having problem on old OSs. Sorry :)                               |
|                                                                                                                                   |
| The sample registry belongs to this SDK. You can edit it whatever, whenver you want, but we still                                 |
| recommended some keys need to be edited:                                                                                          |
|                                                                                                                                   |
| 1. [HKEY_CURRENT_USER\Software\Microsoft\Microsoft Games\Flight Simulator\10.0]                                                   |
|    "AppPath"="./"                                                                                                                 |
|                                                                                                                                   |
|    Replace "./" with your FSX's installation path, for example:                                                                   |
|    "AppPath"="C:\\FSX" (installed in C:\FSX)                                                                                      |
|    "AppPath"="D:\\Games\\FSX" (installed in D:\Games\FSX)                                                                         |
|    "AppPath"="C:\\Program Files\\Microsoft Games\\Flight Simulator X Remake" (installed in C:\Program Files                       |
|                                                                           \Microsoft Games\Flight Simulator X Remake)             |
| 2. [HKEY_CURRENT_USER\Software\FSDreamTeam]                                                                                       |
|     "pushbackdisabled_fsx"=dword:00000001                                                                                         |
|     "jetwaysdisabled_fsx"=dword:00000001                                                                                          |
|     "pushbackdisabled_fsxse"=dword:00000000                                                                                       |
|     "jetwaysdisabled_fsxse"=dword:00000000                                                                                        |
|     "pushbackdisabled_prepar3d"=dword:00000000                                                                                    |
|     "jetwaysdisabled_prepar3d"=dword:00000000                                                                                     |
|     "pushbackdisabled_prepar3dv2"=dword:00000000                                                                                  | 
|     "jetwaysdisabled_prepar3dv2"=dword:00000000                                                                                   |
|     "pushbackdisabled_prepar3dv3"=dword:00000000                                                                                  |
|     "jetwaysdisabled_prepar3dv3"=dword:00000000                                                                                   |
|     "pushbackdisabled_prepar3dv4"=dword:00000000                                                                                  |
|     "jetwaysdisabled_prepar3dv4"=dword:00000000                                                                                   |
|     "root"=".\\Additional FSX Add-ons\\GSX"                                                                                       |
|                                                                                                                                   |
|    Replace ".\" with your FSX's installation path, for example:                                                                   | 
|    "AppPath"="C:\\FSX\\Additional FSX Add-ons\\GSX" (installed in C:\FSX)                                                         |
|    "AppPath"="D:\\Games\\FSX\\Additional FSX Add-ons\\GSX" (installed in D:\Games\FSX)                                            |
|    "AppPath"=C:\\Program Files\\Microsoft Games\\Flight Simulator X Remake\\Additional FSX Add-ons\\GSX" (installed in C:\Program |
|                                                                                   Files\Microsoft Games\Flight Simulator X Remake)|
-------------------------------------------------------------------------------------------------------------------------------------




---------------------------------------------- Using 7-Zip File Manager to install FSX ----------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------
|                                                                                                                                   |
| Download 7-Zip here: https://www.7-zip.org/download.html                                                                          |
|                                                                                                                                   |
| Mount the iso, open it and go to the "Data" folder. In that,                                                                      |
| you'll see 7 files in ".wim" file. Extract it using 7zFM into the folder you want.                                                |
|                                                                                                                                   |
| Extract ".wim" from 7-Zip is a good choice if you try to install on the older machine, like Windows XP or Vista                   |
|                                                                                                                                   |
| Back to the mounted volume and go to folder "Remake Settings", you'll see a batch file. Run it                                    |
| as administrator, all compoments will be installed. Just follow the intructions in there.                                         |
|                                                                                                                                   |
| That's it.                                                                                                                        |
-------------------------------------------------------------------------------------------------------------------------------------



